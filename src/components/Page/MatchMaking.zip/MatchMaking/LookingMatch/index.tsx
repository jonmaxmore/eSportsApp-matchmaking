import React from "react";

const LookingMatch = () => {
  return (
    <div>
      <h1>LookingMatch</h1>
    </div>
  );
};
export default LookingMatch;